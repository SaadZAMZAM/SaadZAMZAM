package com.example.interrupteur;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import java.lang.String;
import java.util.ArrayList;


public class switchsetting extends AppCompatActivity {



    ArrayAdapter<String> ad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_switchsetting);
        interbd intbd = new interbd(switchsetting.this, "bdinter", null, 3);
        final ListView lsint = findViewById(R.id.lsinter);
        ArrayList<String> al = intbd.getinter();
        ad = new ArrayAdapter<>(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, al);
        lsint.setAdapter(ad);
        lsint.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                gotoUrl("http://192.168.1.3/");

            }
        });
    }

       @Override
       public boolean onCreateOptionsMenu(Menu menu){
           MenuInflater inflater = getMenuInflater();
           inflater.inflate(R.menu.menu_main, menu);
           return true;
       }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){
            case R.id.addswitch:
                Intent intent = new Intent(this, addswitch.class);
                startActivity(intent);
                return true;
            case R.id.modif:
                Intent intent2 = new Intent(this, modifswitch.class);
                startActivity(intent2);
                return true;
            case R.id.desc:
                Intent intent4 = new Intent(this, Activity2.class);
                startActivity(intent4);
                return true;
        }
        return false;
    }


      private void gotoUrl(String s) {
          Uri uri = Uri.parse(s);
          startActivity(new Intent(Intent.ACTION_VIEW,uri));
      }
}




