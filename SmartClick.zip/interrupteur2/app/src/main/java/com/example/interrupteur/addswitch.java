package com.example.interrupteur;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class addswitch extends AppCompatActivity {
    private EditText edtNom, edtid;
    private Button btnAjouter;
    private ArrayAdapter<String> ad;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addswitch);
        final interbd intbd = new interbd(this, "bdinter", null, 3);
        edtNom = (EditText) findViewById(R.id.switchname);
        edtid = (EditText) findViewById(R.id.switchcode);
        ListView lsinter = findViewById(R.id.lsinter);
        btnAjouter = (Button) findViewById(R.id.btnadd);
        btnAjouter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Interrupteur inter = new Interrupteur(edtNom.getText().toString(), Integer.parseInt(edtid.getText().toString()));
                intbd.ajouterinter(inter);
                ArrayList<String> al = intbd.getinter();
                ad = new ArrayAdapter<>(addswitch.this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, al);
                lsinter.setAdapter(ad);
            }
        });

    }
}