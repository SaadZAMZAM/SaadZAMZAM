package com.example.interrupteur;


import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.util.ArrayList;

public class Activity2 extends AppCompatActivity {
    private Button connexion;
    private Button creeacc;
    private EditText edtlog,edtpass;
    ArrayList<String> ls;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        edtlog = findViewById(R.id.log);
        edtpass = findViewById(R.id.pass);
        connexion = (Button) findViewById(R.id.connexion);
        creeacc = (Button) findViewById(R.id.creeacc);
       final interbd userdb = new interbd(Activity2.this, "bduser", null, 5);
       ls = userdb.getuser();
        ConnectivityManager c = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if(isNetworkAvailable())
        {
            connexion.setEnabled(true);
            creeacc.setEnabled(true);

        }
        else if(c.getActiveNetworkInfo() == null)
        {
            connexion.setEnabled(false);
            creeacc.setEnabled(false);
            Toast toast = Toast.makeText(getApplicationContext(), "Aucun réseau disponible !", Toast.LENGTH_SHORT);
            toast.show();
        }
        connexion.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if (edtlog.getText().toString().length() == 0 || edtpass.getText().toString().length() == 0 || edtpass.getText().toString().length() <= 6) {
                    Toast.makeText(Activity2.this, "enter your information", Toast.LENGTH_SHORT).show();
                } else if(exist()){
                            openswitchsetting();
                        }else{
                            Toast.makeText(Activity2.this, "user not exist, create account", Toast.LENGTH_SHORT).show();
                        }
                    }
        });

        creeacc.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                opennewacc();}

        });
    }
    public void openswitchsetting(){
        Intent intent = new Intent(this, switchsetting.class);
        startActivity(intent);
    }
    public void opennewacc() {
        Intent intent = new Intent(this, newacc.class);
        startActivity(intent);
    }
    public boolean exist() {
        boolean ex = false;

        for (String i : ls) {
            if (i.contains(edtlog.getText().toString()+"-"+edtpass.getText().toString())) {

                ex = true;
            }}
        return ex;
        }
    private Boolean isNetworkAvailable() {
    ConnectivityManager connectivityManager
            = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
    NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
    return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();}
}