package com.example.interrupteur;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class newacc extends AppCompatActivity {
    private EditText edtnom,edtlog,edtpass,edtrepass;
    private Button ajouteruser;
    ArrayAdapter<String> au;
    ArrayList<String> ls;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newacc);
        final interbd userbd = new interbd(this, "bduser", null, 5);
        edtnom = (EditText) findViewById(R.id.name);
        edtlog = (EditText) findViewById(R.id.mail);
        edtpass = (EditText) findViewById(R.id.password);
        edtrepass = (EditText) findViewById(R.id.repassword);
        ajouteruser = findViewById(R.id.btnsave);
        ListView lsuser = findViewById(R.id.lsuser);
        final interbd userdb = new interbd(newacc.this, "bduser", null, 5);
        ls = userdb.getuser();
            ajouteruser.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (edtnom.getText().toString().length() == 0 || edtlog.getText().toString().length() == 0 || edtpass.getText().toString().length() == 0 || edtrepass.getText().toString().length() == 0|| edtpass.getText().toString().length() <= 6 || edtrepass.getText().toString().length() <= 6) {
                        Toast.makeText(newacc.this, "enter your information", Toast.LENGTH_SHORT).show();
                    } else if (!(isEmailValid(edtlog.getText().toString())) || (edtpass.getText().toString().length() < 7) || !(edtpass.getText().toString().equals(edtrepass.getText().toString()))) {
                        Toast.makeText(newacc.this, "change information", Toast.LENGTH_SHORT).show();
                    } else if(exist()){
                                Toast.makeText(newacc.this, "user exist already", Toast.LENGTH_SHORT).show();
                            }else {
                                user u = new user(edtnom.getText().toString(), edtlog.getText().toString(), edtpass.getText().toString());
                                userbd.newuser(u);
                                Toast.makeText(newacc.this, "user added succefuly", Toast.LENGTH_SHORT).show();
                                openbaseuser();

                            }

                }
            });

    }
    public void openbaseuser() {
        Intent intent = new Intent(this, switchsetting.class);
        startActivity(intent);
    }
    public boolean isEmailValid(CharSequence email) {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }
 public boolean exist() {
        boolean ex = false;

     for (String i : ls) {
         if (i.contains(edtlog.getText().toString() + "-" + edtpass.getText().toString())) {
             ex = true;
         }}
         return ex;
     }}