package com.example.interrupteur;


public class Interrupteur {
    private int id;
    private String nom;

    public Interrupteur() {}

    public Interrupteur(String nom, int id)
    {
        this.nom = nom;
        this.id = id;

    }

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }
    public String getNom() {
        return nom;
    }

    public void setNom(String nom)
    {
        this.nom = nom;
    }

    public String toString()
    {
        return "id : " + id + "\nnom : " + nom ;
    }

}
