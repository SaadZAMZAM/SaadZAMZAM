package com.example.interrupteur;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;
import java.util.ArrayList;


public class interbd extends SQLiteOpenHelper {

    public interbd(@Nullable Context context,@Nullable String name,@Nullable SQLiteDatabase.CursorFactory factory, int version){
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE usertable(username TEXT,login TEXT , pass TEXT)");
        db.execSQL("CREATE TABLE intertable(idinter INTEGER , nominter TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS intertable");
        db.execSQL("DROP TABLE IF EXISTS usertable");
        onCreate(db);
    }
    public Boolean connexion(String log,String pass){
        SQLiteDatabase db = this.getWritableDatabase();
        Boolean connect = false;
        Cursor cur = db.rawQuery("SELECT * FROM usertable WHERE login = "+log+" AND pass = "+pass,null);
        if(cur.moveToFirst()){
            connect = true;
        }
        db.close();
        return connect;
    }
    public void newuser(user u){
        SQLiteDatabase dbu = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("username" , u.getNom());
        cv.put("login", u.getLog());
        cv.put("pass", u.getPass());
        dbu.insert("usertable", null,cv);
        dbu.close();
    }

    public void ajouterinter(Interrupteur inter){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("idinter" , inter.getId());
        cv.put("nominter", inter.getNom());
        db.insert("intertable", null,cv);
        db.close();
    }
    @SuppressLint("Range")
    public ArrayList<String> getuser(){
        SQLiteDatabase dbu = this.getWritableDatabase();
        Cursor cur = dbu.rawQuery("SELECT * FROM usertable",null);
        ArrayList<String> sl = new ArrayList<>();
        cur.moveToFirst();
        while(cur.isAfterLast()==false){
            String id;
            String nom;
            String pass;
            nom = cur.getString(cur.getColumnIndex("username"));
            id = cur.getString(cur.getColumnIndex("login"));
            pass = cur.getString(cur.getColumnIndex("pass"));
            sl.add(id+"-"+pass);
            cur.moveToNext();
        }
        dbu.close();
        return sl;
    }
    @SuppressLint("Range")
    public ArrayList<String> getinter(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cur = db.rawQuery("SELECT * FROM intertable",null);
        ArrayList<String> al = new ArrayList<>();
        cur.moveToFirst();
        while(cur.isAfterLast()==false){
            int id;
            String nom;
            id = cur.getInt(cur.getColumnIndex("idinter"));
            nom = cur.getString(cur.getColumnIndex("nominter"));
            al.add( nom );
            cur.moveToNext();
        }
        db.close();
        return al;
    }
   @SuppressLint("Range")
    public ArrayList<Interrupteur> Retournerinter(String value){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cur = db.rawQuery("SELECT * FROM intertable WHERE nominter LIKE ?",new String[]{"%"+value+"%"});
        ArrayList<Interrupteur> al = new ArrayList<>();
        cur.moveToFirst();
        while(cur.isAfterLast()==false){
            int id;
            String nom;
            id = cur.getInt(cur.getColumnIndex("idinter"));
            nom = cur.getString(cur.getColumnIndex("nominter"));
            Interrupteur inter = new Interrupteur(nom,id);
            al.add(inter);
            cur.moveToNext();
        }
        db.close();
        return al;
    }
    public void modifierswitch(String id,String nom){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("nominter",nom);
        db.update("intertable",cv,"idinter=?",new String[]{String.valueOf(id)});
        db.close();
    }
    public void suppswitch(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("intertable","idinter=?",new String[]{String.valueOf(id)});
        db.close();
    }

}
