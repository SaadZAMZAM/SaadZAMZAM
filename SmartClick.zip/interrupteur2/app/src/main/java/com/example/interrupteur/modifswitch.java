package com.example.interrupteur;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;

public class modifswitch extends AppCompatActivity {
    private Spinner spinter;
    EditText nom, ide;
    interbd intbd;
    ListView lsinter;
    private ArrayList<Interrupteur> al;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modifswitch);
        intbd = new interbd(modifswitch.this,"bdinter",null,3);
        nom = (EditText) findViewById(R.id.switchname);
        ide = (EditText) findViewById(R.id.switchcode);
        lsinter = findViewById(R.id.lsinter);
        spinter = findViewById(R.id.spinter);
        spiinter();
        spinter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                nom.setText(al.get(position).getNom().toString());
                ide.setText(String.valueOf(al.get(position).getId()).toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        Button btnmodifier = findViewById(R.id.btnadd);
        btnmodifier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intbd.modifierswitch(String.valueOf(ide.getText()).toString(),nom.getText().toString());
                AlertDialog.Builder msgmodif = new AlertDialog.Builder(modifswitch.this);
                msgmodif.setMessage("Modification Done")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                ArrayList<String> al = intbd.getinter();
                                ArrayAdapter<String> ad = new ArrayAdapter<>(modifswitch.this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, al);
                                lsinter.setAdapter(ad);
                            }
                        });
                msgmodif.show();
            }
        });
        Button btnsupp = findViewById(R.id.btndelete);
        btnsupp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder msgsupp = new AlertDialog.Builder(modifswitch.this);
                msgsupp.setTitle("Delete")
                        .setMessage("Do you want to delete this switch ?")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                intbd.suppswitch(String.valueOf(ide.getText()).toString());
                                ArrayList<String> al = intbd.getinter();
                                ArrayAdapter<String> ad = new ArrayAdapter<>(modifswitch.this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, al);
                                lsinter.setAdapter(ad);
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        })
                        .show();
            }
        });
    }

    private void spiinter() {
         al = intbd.Retournerinter("");
        ArrayList<String> ls = new ArrayList<String>();
        for(Interrupteur inter : al){
            ls.add(inter.getNom());
        }
        ArrayAdapter<String> ad = new ArrayAdapter<String>(this,androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, ls);
        spinter.setAdapter(ad);
    }
}