package com.example.interrupteur;

public class user {
    private String log;
    private String nom;
    private String pass;

    public user() {}

    public user(String nom,String log, String pass)
    {
        this.log = log;
        this.nom = nom;
        this.pass = pass;

    }
    public String getLog()
    {
        return log;
    }

    public void setLog(String log)
    {
        this.log = log;
    }
    public String getNom() {
        return nom;
    }

    public void setNom(String nom)
    {
        this.nom = nom;
    }
    public String getPass() {
        return pass;
    }

    public void setPass(String pass)
    {
        this.pass = pass;
    }

    public String toString()
    {
        return "nom : " + nom + "\nlogin : " + log + "\npassword : "+pass ;
    }

}
